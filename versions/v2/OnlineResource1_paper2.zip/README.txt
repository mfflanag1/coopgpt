Online Resource 1
=================
Article:  Exact and stable games need not be egalitarian stable
Author:   Maxwell Flanagan [Affiliation - to be completed]
Contact:  maxwell.flanagan@gmail.com

Caption:  Exact-rational certificates for all witnesses (coalition functions,
          generator points, egalitarian claims, admissible collections,
          procedural egalitarian solutions and their core violations,
          per-coalition exactness witnesses for the primary five-player game,
          and, for the two six-player stable-core witnesses, the two-point
          generator representation, the fully-tight coalition list certifying
          the segment core, and the statistics of the arrangement-vertex
          stability enumeration), with a self-contained verifier
          (Python >= 3.8 standard library only).
          Run:  python3 verify_paper2.py   (expects supplement_data.json
          alongside or one directory up; output ends "ALL CHECKS PASSED").
          The core-stability certificate itself is a large exhaustive
          computation (41.5 million vertex bases per game, every outside-core
          vertex discarded against an exact rational dominating core element);
          the verifier re-checks all surrounding claims and records the run
          statistics rather than re-running the enumeration.
Contents: verify_paper2.py, README.txt, supplement_data.json.
