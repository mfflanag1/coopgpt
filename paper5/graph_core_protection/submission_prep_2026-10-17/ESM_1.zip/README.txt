Online Resource 1 — Acyclicity and simultaneous protection of individual core maxima
Submission candidate for International Journal of Game Theory
Author: Maxwell Flanagan
Affiliation/corresponding email: author confirmation required before submission.

This supplement contains constructed rational instances, verification code,
recorded finite results, and the exact accompanying manuscript source. It contains
no empirical data, third-party article PDFs, private correspondence, or model
review transcripts. Complete universal proofs are in the manuscript; these
finite computations are corroboration and do not establish historical priority.

Extract to a new writable directory before replay; scripts regenerate reports.
Standard-library rational suite: bash build.sh
Full tree/cyclic/simultaneous exact-solver suite:
  COOPGT_PYTHON=/path/to/python bash build.sh --smt
The14October2026 replay used Python3.10.14 and z3-solver5.0.0.0, already installed.
requirements-tested.txt records this exact package version. requirements-smt.txt
preserves the historical5.1.0.0 pin; it was not freshly executed in this pass.
No package installation or network is required for the standard-library suite.
With a conventional existing LaTeX installation: bash build.sh --pdf
The desktop editor can compile paper/manuscript.tex without a terminal TeX install.

Coverage: 120 tree clipping cases (56 strict improvements); 822,002 graph-family
full-team inequalities, 33,864 graph masks, 12 raw-core UNSAT queries and four
rejected corrupt certificates; 2,553,912 simultaneous full-team inequalities,
16 raw-core simplex/ideal/protection UNSAT queries for q1..4, vertex/witness
checks through q8, six cyclic extensions and three rejected corrupt inputs.
Graph masks test the support/embedding step, not a census of all possible games.
The proof quantifies over every admissible finite market and all parameters.

SHA256SUMS.json binds this supplied snapshot. Generated reports can change during
replay; use a fresh extraction and retain the new outcome separately.

DATED SUCCESSOR -17October2026
Read Online_Resource_1_Readme.pdf for portable installation and scope.
Use: python3.10 -m venv .venv
Then: .venv/bin/python -m pip install -r requirements-tested.txt
Then: COOPGT_PYTHON="$PWD/.venv/bin/python" bash build.sh --smt
A fresh Python3.10.14 environment installed5.0.0.0 and passed all three stages.
The model-through-proof source is unchanged; only title-page and bibliographic
presentation changed. All verification code is unchanged. Author identity,
affiliation and contact metadata still require confirmation.
Full-original comparisons for Quint1991/Lucas1995/Stuart1997 remain incomplete.
Internal proof/model reviews are not external specialist endorsement.
