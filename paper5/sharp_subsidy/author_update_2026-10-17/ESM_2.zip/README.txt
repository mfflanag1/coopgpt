REPRODUCE — 17 OCTOBER2026
Sharp subsidies for protecting core maxima in three-sided assignment markets
Confirmed sole author: Maxwell Flanagan; no affiliation.
Corresponding contact and city/country remain to be supplied.

MATHEMATICAL CHECKS
ESM_2.zip contains verification/ and validation/FRESH_SHARP_CHECKS.json.
Extract into a disposable new directory and choose a NEW output path:
  python3 -B -O verification/verify.py --output fresh-check.json
Tested: Python3.10.14, standard library only. No solver, external data, network
or GPU. The runner checks frozen input hashes and temp-isolates the historical
tree checker. The optional output is written to the supplied path: use a new
file rather than overwriting source or the supplied historical evidence.
Fresh pass:27 label triples;4 per-label polynomial identities;2 global slack
identities;28 altered symbolic identities rejected;48 rational packing cases;
4 enriched necessary-condition points;2 rejected relaxed false points and1
fractional-scope example;12 family sizes;3,603,804 full-team inequalities;
12 damaged allocations rejected. The enriched points are not certified market
realizations. These are finite corroboration, not proof of the universal claim.
Historical checker parameter q means the manuscript's family parameter ell;
its scalar budget B is the manuscript's beta. These names are not new models.
Only this focused suite was rerun; A–C appendix suites were not rerun.

SOURCE BUILD
Extract LATEX_SOURCES.zip into an empty directory, then use TeX Live/latexmk:
  latexmk -pdf -interaction=nonstopmode -halt-on-error manuscript.tex
  latexmk -pdf -interaction=nonstopmode -halt-on-error supplement.tex
Both sources are standalone, with no external bibliography/figure/input files.
CLEAN_BUILD.json binds the extracted inputs and exported PDFs. ESM_1.pdf is an
exact-byte alias of supplement.pdf. The desktop compiler was also checked.

REVIEW PROVENANCE
provenance/ holds the exact historical reviewed source/request, corrections and
adjudication. CONSISTENCY_AUDIT describes the literal patch recovery to corrected
Oct3 and the Oct7 changes. UNCHANGED_MATH binds retained main proof environments.
reviews/ records the new focused reorganization review and root adjudication.
Internal review is not human peer review, formal verification or novelty proof.
Use PACKAGE_MANIFEST.json and SHA256SUMS to verify final files; neither checksum
manifest hashes itself. No frozen canonical archive was replaced.
