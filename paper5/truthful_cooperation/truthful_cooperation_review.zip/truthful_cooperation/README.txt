Subsidies for truthful cooperation — review package, 6 October 2026
Maxwell Flanagan

Read output/pdf/specialist_brief.pdf first; manuscript.pdf contains full proofs.
The established model, Banzhaf functional and report convention are credited.
Historical priority and independent human specialist validation remain pending.
The unrestricted constant-budget problem is unresolved.

Python 3.9+ (standard library only):
  python3 -B -O verification/run_all.py
Reports go to validation/replay. Checks remain active under -O. Source and
canonical report hashes are verified; only Python-version metadata is ignored.
FILE_MANIFEST.json records the shipped files. validation/CLEAN_REPLAY.json
records the pre-release clean-directory execution. Finite checks do not replace
the written universal proofs and do not establish novelty.

Each LaTeX source is standalone; compile with the Codex editor or pdflatex twice.
SOURCE_COMPARISON.txt records the source distinctions and remaining gaps.
AI assistance in research, drafting and internal review is disclosed.
Internal model review and unsent outreach drafts are kept in the main repository
https://github.com/mfflanag1/coopgpt/tree/main/paper5/truthful_cooperation
The repository is private; this zip supplies the necessary independent files.
No third-party source PDFs are redistributed.
