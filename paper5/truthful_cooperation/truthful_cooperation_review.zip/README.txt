REVIEW SOURCE PACKET -- 6 October 2026
Subsidies for truthful cooperation: sharp unrestricted bounds in weighted multi-glove games
Maxwell Flanagan

Main result: B_k=(1+o(1)) log k/log log k. The weighted-profile hierarchy
closes the earlier leading-constant gap. Original-owner report incentives,
coalition coverage, arbitrary finite ownerships and all nonnegative real
reports are unchanged. The optional original-core floor preserves this leading
constant. Historical priority and human specialist assessment remain open.

Start with specialist_brief.tex; manuscript Sections2--4 provide model, upper,
hierarchy, weighted-profile transport and full asymptotic proof. Sources passed
the native LaTeX compiler. Compile with a LaTeX editor; stale PDFs are excluded.

With Python3.9+ and no dependencies, run from this directory:
 python3 -B -O verification/run_sharp.py
 python3 -B -O verification/run_hierarchy.py
 python3 -B -O verification/run_all.py
These reproduce24 weighted-profile duals/168 corruption rejections,14 earlier
hierarchy duals/98 corruptions and24 pairwise probabilities, then the six
earlier verifiers. Acceptance checks remain active with -O. Exact finite checks
supplement the proof; they do not establish the universal theorem or novelty.

REVIEW_MANIFEST.json hashes every other member. AI assistance in research,
writing and internal model review is disclosed in the manuscript. No human
endorsement, recognized major-open-problem resolution, or priority is claimed.
No third-party articles or private contact/review transcripts are included.
