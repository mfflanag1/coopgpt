# Chain-cycle separation: review supplement

Read `paper/manuscript.pdf` and `review/specialist_packet.pdf`. Editable LaTeX is included. `sources/ORIGINAL_COMPARISONS.md` records the recovered 2023 original and the three unresolved paid-original comparisons; novelty is qualified.

Run `bash build.sh` with Python3.10+ for the standard-library checks. Run `bash build.sh --smt` with z3-solver5.1.0.0 for raw-core exclusions and selected chain cycle certificates. Run `bash build.sh --full` with that Python environment and latexmk to rebuild both PDFs. Set COOPGT_PYTHON to select the Python executable. The optional package version is pinned in certificates/requirements-smt.txt.

The default checks verify two independent routes, each with7,208 exact cyclic cover inequalities at q=1,2,3,4. The full build adds three raw-core cyclic exclusions, three selected chain markets and21 explicit per-player cycle certificates. These checks corroborate the all-parameter conventional proofs in the manuscript; they are not a proof-assistant formalization or an exhaustive class census.

certificates/RESULTS.json is regenerated on each run. A failed run exits nonzero and records FAIL. VALIDATION.json describes the frozen author-side release checks. SOURCE_PROVENANCE.json uses portable source identifiers; the prior research checkout is not needed to replay this archive. SHA256SUMS covers the frozen files, including generated artifacts; rebuilding may change their hashes. PDF byte-for-byte reproduction is not expected because of build timestamps.

This archive contains no third-party paper originals, private browser data, temporary signed download URLs or outreach messages. Nothing has been submitted or sent. The manuscript is anonymous for review.
