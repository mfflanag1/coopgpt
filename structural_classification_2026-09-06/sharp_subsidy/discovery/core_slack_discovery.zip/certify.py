from pathlib import Path
from fractions import Fraction as F
import json,sys
sys.path.insert(0,'/Users/maxf/projects/economics-research/game-theory/coopgt-recovery/coopgames/structural_classification_2026-09-06/sharp_subsidy')
from sector_min_core import core_rows
for b in (2,4,8,12):
 p=Path(__file__).with_name(f'probe_{b}.json');d=json.loads(p.read_text());m=d['m'];P=[tuple(e) for e in d['P']];U=d['U'];edges,rows,_=core_rows(m,P)
 stride=3*m+3;off=len(edges);res=[F(0)]*(off+len(U)*stride)
 y=[min(F(0),F(round(v*10**12),10**12)) for v in d['ineq_dual']];z=[F(round(-v*10**12),10**12) for v in d['eq_dual']]
 if max(y)>0:raise ValueError('dual sign')
 idx={e:k for k,e in enumerate(edges)}
 for j in range(m):
  for k in range(3):res[idx[k,j,j]]+=z[0]
 for k in range(len(U)):
  for v in range(3*m):res[off+k*stride+v]+=z[k+1]
  for r,(es,coeff) in enumerate(rows):
   val=-y[k*len(rows)+r]
   for e in es:res[e]+=val
   for v,c in coeff.items():res[off+k*stride+v]+=val*c
 for a,bb,c in P:
  for e in ((0,a,bb),(1,a,c),(2,bb,c)):res[idx[e]]-=1
 for k,i in enumerate(U):res[off+k*stride+i]-=F(1,3)
 print({'b':b,'minimum_residual':str(min(res)),'upper_J':str(sum(z)-1)},flush=True)
 correction=sum(max(F(0),-v) for v in res)
 upper=sum(z)-1+correction
 if upper-F(d['objective'])>F(1,100000):raise ValueError('dual correction too large')
 out={'b':b,'m':m,'P':P,'U':U,'edges':edges,'T':3*m,'weights':[round(v*3*m) for v in d['weights']], 'witnesses':[[round(v*3*m) for v in x] for x in d['witnesses']], 'dual_ineq':[[k,str(-v)] for k,v in enumerate(y) if v], 'dual_eq':[str(v) for v in z],'fixed_P_upper':str(upper),'box_correction':str(correction)}
 Path(__file__).with_name(f'exact_{b}.json').write_text(json.dumps(out))
