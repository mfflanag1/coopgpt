"""Independent numerical attack on the master inequality using full core LPs."""
import sys,json,time
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
sys.path.insert(0,'/Users/maxf/projects/economics-research/game-theory/coopgt-recovery/coopgames/structural_classification_2026-09-06/sharp_subsidy')
from sector_min_core import core_rows
from universal_template import junctions

def solve(m,P,jmin,name):
 edges,rows,_=core_rows(m,P);idx={e:k for k,e in enumerate(edges)};off=len(edges);stride=3*m+3
 used={(s,e[s]) for e in P for s in range(3)};U=[s*m+j for s in range(3) for j in range(m) if (s,j) not in used]
 deg=[sum((s,j) in used for s in range(3)) for j in range(m)];I=[j for j in range(m) if deg[j]>=2]
 nv=off+(len(U)+3)*stride;rr=[];cc=[];vv=[]
 for k in range(len(U)+3):
  for r,(es,cs) in enumerate(rows):
   for e in es:rr.append(k*len(rows)+r);cc.append(e);vv.append(1)
   for j,v in cs.items():rr.append(k*len(rows)+r);cc.append(off+k*stride+j);vv.append(v)
 nrows=(len(U)+3)*len(rows)
 for j in I:
  if j==jmin:continue
  for p in range(3):rr.extend([nrows,nrows]);cc.extend([idx[p,jmin,jmin],idx[p,j,j]]);vv.extend([1,-1])
  nrows+=1
 A=coo_matrix((vv,(rr,cc)),shape=(nrows,nv)).tocsr();er=[];ec=[]
 for j in range(m):
  for p in range(3):er.append(0);ec.append(idx[p,j,j])
 for k in range(len(U)+3):
  for v in range(3*m):er.append(k+1);ec.append(off+k*stride+v)
 E=coo_matrix((np.ones(len(er)),(er,ec)),shape=(len(U)+4,nv)).tocsr();obj=np.zeros(nv)
 for a,b,c in P:
  for e in ((0,a,b),(1,a,c),(2,b,c)):obj[idx[e]]+=1
 for k,i in enumerate(U):obj[off+k*stride+i]+=1/3
 for j in I:
  for p in range(3):obj[idx[p,j,j]]-=3*61/47
  if deg[j]==2:
   for p in range(3):obj[idx[p,j,j]]+=37/141
  for s in range(3):obj[off+(len(U)+s)*stride+s*m+j]+=61/47
 for p in range(3):obj[idx[p,jmin,jmin]]-=37/94
 start=time.monotonic();r=linprog(-obj,A_ub=A,b_ub=np.zeros(nrows),A_eq=E,b_eq=np.ones(E.shape[0]),bounds=(0,None),options={'time_limit':20})
 out={'case':name,'m':m,'P':P,'minimum_internal_label':jmin,'success':r.success,'message':r.message,'seconds':time.monotonic()-start,'master_lhs_max':-r.fun-1 if r.success else None,'proposed_upper':37/94}
 Path(__file__).with_name(f'master_adversary_{name}.json').write_text(json.dumps(out));print(json.dumps(out),flush=True)
 if r.success and -r.fun-1>37/94+1e-7:raise RuntimeError('candidate master counterexample')

if __name__=='__main__':
 solve(4,[(0,0,1),(1,2,3)],0,'repeated_min0')
 solve(4,[(0,0,1),(1,2,3)],1,'repeated_min1')
 solve(5,[(0,1,2),(3,0,4)],0,'degree_two_tree')
 for b in (2,4):
  m,P=junctions(b);solve(m,P,0,f'branching_{b}')
