import sys
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
sys.path.insert(0,'/Users/maxf/projects/economics-research/game-theory/coopgt-recovery/coopgames/structural_classification_2026-09-06/sharp_subsidy')
from universal_template import junctions
from mixed_donor_template import construct
for b in (4,8,16):
 m,P=junctions(b);pack=construct(m,P);deg=[sum(j in e for e in P) for j in range(m)];used={(s,e[s]) for e in P for s in range(3)}
 cov=defaultdict(F);target=defaultdict(F)
 for i,(a,bb,c),val in pack['packings']:
  for e in ((0,a,bb),(1,a,c),(2,bb,c)):cov[e]+=F(val)
 u=3*(m-len(P))
 for j in range(m):
  for p in range(3):target[p,j,j]+=F(u)-F(21,5)
 for a,bb,c in P:
  for e in ((0,a,bb),(1,a,c),(2,bb,c)):target[e]+=3
 cats=defaultdict(set)
 for (p,a,bb),v in target.items():
  if a==bb:
   s,t=((0,1),(0,2),(1,2))[p]
   cat='hub' if deg[a]==3 else ('leaf_incident' if (s,a) in used or (t,a) in used else 'leaf_residual')
  else:cat='P'
  cats[cat].add(str(cov[p,a,bb]-v))
 print(b,{k:sorted(v) for k,v in cats.items()},flush=True)
