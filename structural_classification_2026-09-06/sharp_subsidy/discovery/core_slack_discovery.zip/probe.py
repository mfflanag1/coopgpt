import sys,json,time
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
ROOT=Path('/Users/maxf/projects/economics-research/game-theory/coopgt-recovery/coopgames/structural_classification_2026-09-06/sharp_subsidy')
sys.path.insert(0,str(ROOT))
from sector_min_core import core_rows
from universal_template import junctions
from mixed_donor_template import construct

def run(b):
 m,P=junctions(b);edges,rows,_=core_rows(m,P);idx={e:k for k,e in enumerate(edges)}
 used={s*m+e[s] for e in P for s in range(3)};U=sorted(set(range(3*m))-used)
 off=len(edges);stride=3*m+3;n=off+len(U)*stride
 rr=[];cc=[];vv=[]
 for k,i in enumerate(U):
  for z,(es,coeff) in enumerate(rows):
   r=k*len(rows)+z
   for e in es:rr.append(r);cc.append(e);vv.append(1)
   for v,c in coeff.items():rr.append(r);cc.append(off+k*stride+v);vv.append(c)
 A=coo_matrix((vv,(rr,cc)),shape=(len(U)*len(rows),n)).tocsr()
 er=[];ec=[]
 for j in range(m):
  for p in range(3):er.append(0);ec.append(idx[p,j,j])
 for k in range(len(U)):
  for v in range(3*m):er.append(k+1);ec.append(off+k*stride+v)
 E=coo_matrix((np.ones(len(er)),(er,ec)),shape=(1+len(U),n)).tocsr()
 c=np.zeros(n)
 for a,bb,ccc in P:
  for e in ((0,a,bb),(1,a,ccc),(2,bb,ccc)):c[idx[e]]+=1
 for k,i in enumerate(U):c[off+k*stride+i]=1/3
 start=time.monotonic()
 r=linprog(-c,A_ub=A,b_ub=np.zeros(A.shape[0]),A_eq=E,b_eq=np.ones(E.shape[0]),bounds=(0,None),options={'time_limit':45})
 record={'b':b,'m':m,'P':P,'U':U,'edges':edges,'success':r.success,'message':r.message,'seconds':time.monotonic()-start}
 if not r.success:
  Path(__file__).with_name(f'probe_{b}_status.json').write_text(json.dumps(record));print(json.dumps({k:record[k] for k in ('b','m','success','message','seconds')}),flush=True);return
 record.update({'objective':-r.fun-1,'weights':r.x[:off].tolist(),'witnesses':[r.x[off+k*stride:off+k*stride+3*m].tolist() for k in range(len(U))], 'ineq_dual':r.ineqlin.marginals.tolist(),'eq_dual':r.eqlin.marginals.tolist()})
 Path(__file__).with_name(f'probe_{b}.json').write_text(json.dumps(record))
 print(json.dumps({'phase':'solved','b':b,'m':m,'J':record['objective'],'seconds':record['seconds']}),flush=True)
 pack=construct(m,P);xs=dict(zip(U,record['witnesses']));loads={i:np.zeros(3*m) for i in U};coverage=defaultdict(float);team_slack=defaultdict(float)
 weights=dict(zip(edges,record['weights']))
 degree=[sum(j in e for e in P) for j in range(m)]
 for i,e,coef in pack['packings']:
  mass=float(F(coef));a,bb,ccc=e
  ep=((0,a,bb),(1,a,ccc),(2,bb,ccc))
  for s,j in enumerate(e):loads[i][s*m+j]+=mass
  for pair in ep:coverage[pair]+=mass
  val=sum(weights.get(pair,0) for pair in ep)
  kind='diagonal' if a==bb==ccc else ('P' if tuple(e) in P else 'completion')
  team_slack[kind]+=mass*(sum(xs[i][s*m+j] for s,j in enumerate(e))-val)
 cap=defaultdict(float)
 for i in U:
  for v,x in enumerate(xs[i]):
   if v!=i:cap[f'degree_{degree[v%m]}']+=(1-loads[i][v])*x
 target=defaultdict(float)
 for j in range(m):
  for p in range(3):target[p,j,j]+=len(U)-21/5
 for a,bb,ccc in P:
  for pair in ((0,a,bb),(1,a,ccc),(2,bb,ccc)):target[pair]+=3
 pairslack=sum((coverage[e]-target[e])*weights[e] for e in edges)
 details={'capacity':dict(cap),'team':dict(team_slack),'pair':pairslack,'total':sum(cap.values())+sum(team_slack.values())+pairslack,'expected':3*(.4-record['objective'])}
 Path(__file__).with_name(f'slack_{b}.json').write_text(json.dumps(details,indent=2))
 print(json.dumps({'b':b,'slack':details}),flush=True)

if __name__=='__main__':
 for b in map(int,sys.argv[1:]):run(b)
