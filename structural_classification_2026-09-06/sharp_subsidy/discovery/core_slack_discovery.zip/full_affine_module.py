from itertools import product
from fractions import Fraction as F
from pathlib import Path
import json
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
m=3;P=(1,2,0)
def pairs(t):
 a,b,c=t;return [(0,a,b),(1,a,c),(2,b,c)]
edges=sorted({e for t in [(j,j,j) for j in range(m)]+[P] for e in pairs(t)});idx={e:k for k,e in enumerate(edges)}
U=[i for i in range(9) if i not in [1,5,6]];off=len(edges);n=off+len(U)*9;teams=list(product(range(m),repeat=3));rr=[];cc=[];vv=[]
for k,i in enumerate(U):
 for r,t in enumerate(teams):
  for e in pairs(t):
   if e in idx:rr.append(k*27+r);cc.append(idx[e]);vv.append(1)
  for s,j in enumerate(t):rr.append(k*27+r);cc.append(off+k*9+s*3+j);vv.append(-1)
A=coo_matrix((vv,(rr,cc)),shape=(162,n)).tocsr();er=[];ec=[]
for j in range(m):
 for p in range(3):er.append(0);ec.append(idx[p,j,j])
for k,i in enumerate(U):
 for v in range(9):er.append(k+1);ec.append(off+k*9+v)
E=coo_matrix((np.ones(len(er)),(er,ec)),shape=(7,n)).tocsr();c=np.zeros(n)
for e in pairs(P):c[idx[e]]+=1
for k,i in enumerate(U):c[off+k*9+i]+=1/3
for p in range(3):c[idx[p,0,0]]-=17/18
r=linprog(-c,A_ub=A,b_ub=np.zeros(162),A_eq=E,b_eq=np.ones(7),bounds=(0,None))
if not r.success:raise RuntimeError(r.message)
d={'m':3,'P':P,'U':U,'edges':edges,'affine_coefficient':'17/18','y':[str(F(-v).limit_denominator(10000)) for v in r.ineqlin.marginals],'z':[str(F(-v).limit_denominator(10000)) for v in r.eqlin.marginals],'floating_objective':-r.fun}
Path(__file__).with_name('FULL_AFFINE_MODULE.json').write_text(json.dumps(d));print({'objective':-r.fun,'dual_sum':str(sum(map(F,d['z'])))})
