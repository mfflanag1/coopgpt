from pathlib import Path
from fractions import Fraction as F
from math import lcm
import json,sys
sys.path.insert(0,'/Users/maxf/projects/economics-research/game-theory/coopgt-recovery/coopgames/structural_classification_2026-09-06/sharp_subsidy')
from verify_cyclic_patterns import check
root=Path(__file__).parent;recs=json.loads((root/'CYCLIC_FRONTIER_EXACT_RESULTS.json').read_text());names=[d['name']for d in recs if d['status']=='PASS']+['CYCLIC_FRONTIER_COUNT_TWIN'];out=[]
for name in names:
 d=json.loads((root/(name+'.json')).read_text());base=check(d);best=d;result=base
 for lim in (100,1000,10000):
  lm=[[j,F(w,d['denominator']).limit_denominator(lim)]for j,w in d['inequality_multipliers']];nu=[F(w,d['denominator']).limit_denominator(lim)for w in d['equality_multipliers']];D=lcm(*(w.denominator for j,w in lm),*(w.denominator for w in nu));dd=dict(d);dd.update(denominator=D,inequality_multipliers=[[j,int(w*D)]for j,w in lm if w],equality_multipliers=[int(w*D)for w in nu])
  try:rr=check(dd)
  except ValueError:continue
  if F(rr['fixed_pattern_upper'])<F(result['fixed_pattern_upper']):best,result=dd,rr
  if rr['fixed_pattern_upper']==rr['fixed_pattern_lower']:break
 (root/(name+'.json')).write_text(json.dumps(best)+'\n');result['name']=name;out.append(result);print(name,result['fixed_pattern_lower'],result['fixed_pattern_upper'],flush=True)
(root/'CYCLIC_FRONTIER_TIGHT_RESULTS.json').write_text(json.dumps(out)+'\n')
