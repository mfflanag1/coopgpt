from pathlib import Path
from fractions import Fraction as F
import json,numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from sympy import Matrix
from sympy.polys.matrices import DomainMatrix
from sparse_fixed_probe import layout

def recover(x,teams,worth,m,lower,total=None):
 n=3*m;rows=[]
 if total is not None:rows.append([1]*n+[F(total)])
 for (t,es),v in zip(teams,worth):
  if abs(sum(x[s*m+j]for s,j in enumerate(t))-float(v))<1e-7:
   row=[F(0)]*n
   for s,j in enumerate(t):row[s*m+j]=1
   rows.append(row+[v])
 for i,v in enumerate(lower):
  if abs(x[i]-float(v))<1e-7:
   row=[F(0)]*n;row[i]=1;rows.append(row+[v])
 dm,piv=DomainMatrix.from_Matrix(Matrix(rows)).rref();mat=dm.to_Matrix()
 if n in piv:raise ValueError('inconsistent active face')
 y=[F(round(float(v)*10**9),10**9)for v in x];free=[i for i in range(n)if i not in piv]
 for k,i in enumerate(piv):y[i]=F(mat[k,n])-sum(F(mat[k,j])*y[j]for j in free)
 if not all(a>=b for a,b in zip(y,lower)):raise ValueError('lower violated')
 if total is not None and sum(y)!=total:raise ValueError('total violated')
 if not all(sum(y[s*m+j]for s,j in enumerate(t))>=v for (t,es),v in zip(teams,worth)):raise ValueError('coalition violated')
 return y

def sparse_dual(values,negative=False):return [[i,str(F(float(-v if negative else v)).limit_denominator(100000))]for i,v in enumerate(values)if abs(v)>1e-9]
root=Path(__file__).parent;recs=json.loads((root/'CYCLIC_FRONTIER_ACTUAL_DISCOVERY.json').read_text())
for rec in recs:
 name=rec['name'];d=json.loads((root/(name+'.json')).read_text());m=d['m'];P=d['P'];supp,idx,U,teams=layout(m,P);weights=[F(v,d['primal_scale'])for v in d['primal_integers'][:len(supp)]];worth=[sum(weights[e]for e in es)for t,es in teams];n=3*m;ii=[];jj=[]
 for k,(t,es)in enumerate(teams):
  for s,j in enumerate(t):ii.append(k);jj.append(s*m+j)
 A=coo_matrix((np.ones(len(ii)),(ii,jj)),shape=(len(teams),n)).tocsr();H=[];core=[];duals=[]
 for i in range(n):
  c=np.zeros(n);c[i]=-1;r=linprog(c,A_ub=-A,b_ub=[-float(v)for v in worth],A_eq=np.ones((1,n)),b_eq=[1],bounds=(0,None));x=recover(r.x,teams,worth,m,[F(0)]*n,F(1));H.append(x[i]);core.append(list(map(str,x)));lam=sparse_dual(r.ineqlin.marginals,True);nu=F(float(-r.eqlin.marginals[0])).limit_denominator(100000);coeff=[nu]*n;bound=nu
  for z,w in lam:
   w=F(w);bound-=w*worth[z]
   for s,j in enumerate(teams[z][0]):coeff[s*m+j]-=w
  if not all(v>=int(j==i)for j,v in enumerate(coeff))or bound!=H[-1]:raise ValueError('core dual failed')
  duals.append({'lambda':lam,'nu':str(nu)})
 r=linprog(np.ones(n),A_ub=-A,b_ub=[-float(v)for v in worth],bounds=[(float(v/3),None)for v in H]);y=recover(r.x,teams,worth,m,[v/3 for v in H]);lam=sparse_dual(r.ineqlin.marginals,True);mu=[F(float(v)).limit_denominator(100000)for v in r.lower.marginals];caps=list(mu);bound=sum(a*b/3 for a,b in zip(mu,H))
 for z,w in lam:
  w=F(w);bound+=w*worth[z]
  for s,j in enumerate(teams[z][0]):caps[s*m+j]+=w
 if any(v<0 for v in mu)or any(v>1 for v in caps)or bound!=sum(y):raise ValueError('subsidy dual failed')
 out={'name':name,'m':m,'P':P,'weights':[str(v)for v in weights],'H':list(map(str,H)),'core_witnesses':core,'ideal_upper_duals':duals,'protected_y':list(map(str,y)),'subsidy_dual':{'lambda':lam,'mu':list(map(str,mu))},'subsidy':str(sum(y)-1),'original_fixed_P_objective':str(F(d['floating_objective']).limit_denominator(1000000))}
 (root/(name+'_FULL_EXACT.json')).write_text(json.dumps(out)+'\n');print(name,out['subsidy'],flush=True)
