from pathlib import Path
from fractions import Fraction as F
from math import lcm
import json,sys,time
from sympy import Matrix
from sympy.polys.matrices import DomainMatrix
from sparse_fixed_probe import layout
sys.path.insert(0,'/Users/maxf/projects/economics-research/game-theory/coopgt-recovery/coopgames/structural_classification_2026-09-06/sharp_subsidy')
from verify_cyclic_patterns import check
root=Path(__file__).parent
for name in [f'CYCLIC_FRONTIER_{r}_1_{seed}'for r in (2,3,4)for seed in range(3)]:
 d=json.loads((root/(name+'.json')).read_text());base=check(d);
 if base['fixed_pattern_lower']==base['fixed_pattern_upper']:print(name,'already exact',flush=True);continue
 m=d['m'];supp,idx,U,teams=layout(m,d['P']);off=len(supp);nv=off+len(U)*3*m;support=[j for j,w in d['inequality_multipliers']];K=len(support);n=K+len(U)+1;cols=[{}for _ in range(nv)];c=[F(0)]*nv
 for a,b,cc in d['P']:
  for e in((0,a,b),(1,a,cc),(2,b,cc)):c[idx[e]]+=1
 for k,i in enumerate(U):c[off+k*3*m+i]=F(1,3)
 for z,row in enumerate(support):
  k,tj=divmod(row,len(teams));t,es=teams[tj]
  for e in es:cols[e][z]=1
  for s,j in enumerate(t):cols[off+k*3*m+s*m+j][z]=-1
 for j in range(m):
  for s in range(3):cols[idx[s,j,j]][K]=1
 for k in range(len(U)):
  for j in range(3*m):cols[off+k*3*m+j][K+k+1]=1
 old=[F(w,d['denominator'])for j,w in d['inequality_multipliers']]+[F(w,d['denominator'])for w in d['equality_multipliers']];active=[j for j,row in enumerate(cols)if abs(float(sum(old[k]*v for k,v in row.items())-c[j]))<1e-5]
 system=[[cols[j].get(k,0)for k in range(n)]+[c[j]]for j in active];system.append([0]*K+[1]*(len(U)+1)+[1+F(base['fixed_pattern_lower'])]);print(name,'matrix',len(system),n,flush=True)
 mat,piv=DomainMatrix.from_Matrix(Matrix(system)).rref();mat=mat.to_Matrix()
 if n in piv:raise ValueError('inconsistent dual face')
 free=[k for k in range(n)if k not in piv];v=list(old)
 for z,k in enumerate(piv):v[k]=F(mat[z,n])-sum(F(mat[z,a])*v[a]for a in free)
 if any(w<0 for w in v[:K])or not all(sum(v[k]*a for k,a in row.items())>=c[j]for j,row in enumerate(cols)):raise ValueError('recovered dual inequality')
 D=lcm(*(w.denominator for w in v));d.update(denominator=D,inequality_multipliers=[[j,int(w*D)]for j,w in zip(support,v[:K])if w],equality_multipliers=[int(w*D)for w in v[K:]])
 result=check(d);print(name,result['fixed_pattern_lower'],result['fixed_pattern_upper'],'rank',len(piv),'free',len(free),flush=True)
 (root/(name+'.json')).write_text(json.dumps(d)+'\n')
