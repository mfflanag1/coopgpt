from pathlib import Path
from fractions import Fraction as F
from math import lcm
import json,sys
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from sparse_fixed_probe import layout
sys.path.insert(0,'/Users/maxf/projects/economics-research/game-theory/coopgt-recovery/coopgames/structural_classification_2026-09-06/sharp_subsidy')
from verify_cyclic_patterns import check
root=Path(__file__).parent;records=json.loads((root/'CYCLIC_FRONTIER_DISCOVERY.json').read_text());out=[]
for rec in records:
 if rec.get('r',99)>4:continue
 if rec['status']!='solved':continue
 name=rec['name'];d=json.loads((root/(name+'.json')).read_text());m=d['m'];support,idx,U,teams=layout(m,d['P']);w=[F(x,d['primal_scale'])for x in d['primal_integers'][:len(support)]];rhs=[sum(w[e]for e in es)for t,es in teams];ii=[];jj=[]
 for k,(t,es)in enumerate(teams):
  for s,j in enumerate(t):ii.append(k);jj.append(s*m+j)
 A=coo_matrix((np.ones(len(ii)),(ii,jj)),shape=(len(teams),3*m)).tocsr();diag=[sum(w[idx[s,j,j]]for s in range(3))for j in range(m)];r=linprog(np.ones(3*m),A_ub=-A,b_ub=[-float(v)for v in rhs],bounds=[(float(diag[j]/3),None)for s in range(3)for j in range(m)])
 if not r.success:raise ValueError(r.message)
 y=[F(float(v)).limit_denominator(100000)for v in r.x];scale=lcm(*(v.denominator for v in y));d['protected_payoff_scale']=scale;d['protected_payoff_integers']=[int(v*scale)for v in y]
 try:result=check(d);result.update(name=name,closures=rec['closures']);out.append(result);(root/(name+'.json')).write_text(json.dumps(d)+'\n');print(name,result['exact_witness_market_subsidy'],result['fixed_pattern_upper'],flush=True)
 except ValueError as e:out.append({'name':name,'status':'not certified','reason':str(e)});print(name,'not certified',e,flush=True)
(root/'CYCLIC_FRONTIER_SMALL_EXACT_RESULTS.json').write_text(json.dumps(out)+'\n')
