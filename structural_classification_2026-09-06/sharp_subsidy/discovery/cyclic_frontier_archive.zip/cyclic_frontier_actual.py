from pathlib import Path
from fractions import Fraction as F
from math import lcm
import json,numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from sparse_fixed_probe import layout
root=Path(__file__).parent;records=json.loads((root/'CYCLIC_FRONTIER_EXACT_RESULTS.json').read_text());out=[]
for rec in records:
 if rec['status']=='PASS':continue
 name=rec['name'];d=json.loads((root/(name+'.json')).read_text());m=d['m'];supp,idx,U,teams=layout(m,d['P']);w=[F(v,d['primal_scale'])for v in d['primal_integers'][:len(supp)]];rhs=[sum(w[e]for e in es)for t,es in teams];ii=[];jj=[]
 for k,(t,es)in enumerate(teams):
  for s,j in enumerate(t):ii.append(k);jj.append(s*m+j)
 A=coo_matrix((np.ones(len(ii)),(ii,jj)),shape=(len(teams),3*m)).tocsr();H=[];witness=[]
 for i in range(3*m):
  c=np.zeros(3*m);c[i]=-1;r=linprog(c,A_ub=-A,b_ub=[-float(v)for v in rhs],A_eq=np.ones((1,3*m)),b_eq=[1],bounds=(0,None))
  if not r.success:raise ValueError(r.message)
  H.append(-r.fun);witness.append(r.x.tolist())
 r=linprog(np.ones(3*m),A_ub=-A,b_ub=[-float(v)for v in rhs],bounds=[(v/3,None)for v in H]);actual=float(r.fun-1)
 out.append({'name':name,'fixed_P':d['floating_objective'],'actual_subsidy':actual,'H':H,'core_witnesses':witness,'y':r.x.tolist(),'dual_teams':r.ineqlin.marginals.tolist(),'dual_floors':r.lower.marginals.tolist()});print(name,'fixed',d['floating_objective'],'actual',actual,flush=True)
(root/'CYCLIC_FRONTIER_ACTUAL_DISCOVERY.json').write_text(json.dumps(out)+'\n')
