from pathlib import Path
import json,sys
from sparse_fixed_probe import layout
sys.path.insert(0,'/Users/maxf/projects/economics-research/game-theory/coopgt-recovery/coopgames/structural_classification_2026-09-06/sharp_subsidy')
from verify_cyclic_patterns import check
root=Path(__file__).parent;d=json.loads((root/'CYCLIC_FRONTIER_8_2_1.json').read_text());m=d['m'];pi=[1,2,0];P=[tuple(t[s]for s in pi)for t in d['P']];old,oi,OU,OT=layout(m,d['P']);new,ni,NU,NT=layout(m,P);ooff=len(old);noff=len(new);old_pair={(0,1):0,(0,2):1,(1,2):2};new_pairs=[(0,1),(0,2),(1,2)]
weights=[]
for pair,a,b in new:
 s,t=new_pairs[pair];s,t=pi[s],pi[t]
 if s>t:s,t=t,s;a,b=b,a
 weights.append(d['primal_integers'][oi[old_pair[s,t],a,b]])
primal=weights[:];nu=[d['equality_multipliers'][0]]
for i in NU:
 s,j=divmod(i,m);oldi=pi[s]*m+j;k=OU.index(oldi);x=d['primal_integers'][ooff+k*3*m:ooff+(k+1)*3*m];primal.extend(x[pi[s]*m+j]for s in range(3)for j in range(m));nu.append(d['equality_multipliers'][k+1])
team_index={tuple(t):k for k,(t,es)in enumerate(NT)};mult=[]
for row,z in d['inequality_multipliers']:
 k,ti=divmod(row,len(OT));s,j=divmod(OU[k],m);newi=pi.index(s)*m+j;nk=NU.index(newi);nt=tuple(OT[ti][0][s]for s in pi);mult.append([nk*len(NT)+team_index[nt],z])
out=dict(d);out.update(P=P,primal_integers=primal,equality_multipliers=nu,inequality_multipliers=mult,protected_payoff_integers=[d['protected_payoff_integers'][pi[s]*m+j]for s in range(3)for j in range(m)],sector_permutation=pi)
print(check(out));(root/'CYCLIC_FRONTIER_COUNT_TWIN.json').write_text(json.dumps(out)+'\n')
