from pathlib import Path
import json,random
from cyclic_frontier_weights import solve

def tree(r,seed):
 rng=random.Random(seed);P=[];available=[(s,0)for s in range(3)];m=1
 for _ in range(r):
  s,j=available.pop(rng.randrange(len(available)));t=[None]*3;t[s]=j
  for a in range(3):
   if a!=s:t[a]=m;available.extend((b,m)for b in range(3)if b!=a);m+=1
  P.append(tuple(t))
 return m,P

def cyclic(r,seed,closures):
 m,P=tree(r,seed);rng=random.Random(seed+9041)
 for _ in range(closures):
  used=[{s for t in P for s,jj in enumerate(t)if jj==j}for j in range(m)];candidates=[(a,b)for a in range(m)for b in range(a+1,m)if used[a].isdisjoint(used[b])and not any(a in t and b in t for t in P)]
  if not candidates:raise ValueError('no admissible closure')
  a,b=rng.choice(candidates)
  def relabel(j):
   if j==b:j=a
   return j-1 if j>b else j
  P=[tuple(relabel(j)for j in t)for t in P];m-=1
 return m,P
if __name__=='__main__':
 records=[]
 for r in (6,8,10):
  for closures in (1,2):
   for seed in range(4):
    name=f'CYCLIC_FRONTIER_{r}_{closures}_{seed}';m,P=cyclic(r,seed,closures)
    try:d=solve(m,P,name);rec={'name':name,'r':r,'closures':closures,'seed':seed,'m':m,'objective':d['floating_objective'],'status':'solved'}
    except RuntimeError as e:rec={'name':name,'status':'not solved','reason':str(e)}
    records.append(rec);Path(__file__).with_name('CYCLIC_FRONTIER_DISCOVERY.json').write_text(json.dumps(records)+'\n')
    if rec.get('objective',0)>1/3+1e-7:print('POTENTIAL_COUNTEREXAMPLE',name,flush=True);raise SystemExit
 print('best',max((v for v in records if v['status']=='solved'),key=lambda v:v['objective']),flush=True)
