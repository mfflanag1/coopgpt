import json
from pathlib import Path
from cycle_boundary_probe import probe
from cyclic_frontier_search import cyclic
out=[]
for m,P,links,name in [(4,[(0,0,1),(1,2,3)],[(0,0,0)],'repeated0'),(4,[(0,0,1),(2,3,0)],[(0,0,0)],'repeated1')]:
 d=probe(m,P,links);d['name']=name;out.append(d);print(name,[(v['zero_pair'],v.get('value'))for v in d['runs']],flush=True)
 Path(__file__).with_name('ADAPTIVE_BOUNDARY_DISCOVERY.json').write_text(json.dumps(out)+'\n')
for r in (3,4,6):
 for seed in (1,2,3,4):
  m,P=cyclic(r,seed,1);d=probe(m,P);d['name']=f'r{r}s{seed}';out.append(d);print(d['name'],[(v['zero_pair'],v.get('value'))for v in d['runs']],flush=True)
  Path(__file__).with_name('ADAPTIVE_BOUNDARY_DISCOVERY.json').write_text(json.dumps(out)+'\n')
  if all(v['success']for v in d['runs']) and d['runs'][0]['value']>max(v['value']for v in d['runs'][1:])+1e-7:raise SystemExit('CANDIDATE EXISTS')
