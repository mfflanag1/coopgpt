from pathlib import Path
from fractions import Fraction as F
from math import lcm
import json
from cyclic_frontier_weights import solve
from verify_cyclic_patterns import check
from verify_cycle_boundary import upper
p=Path(__file__).parent;d=json.loads((p/'ALTERNATING_THREE_COLOR_BOUNDARY.json').read_text())
c=solve(d['m'],d['P'],'ADAPTIVE_BOUNDARY_UNRESTRICTED')
D=c['denominator'];z=[F(v,D).limit_denominator(1000000)for _,v in c['inequality_multipliers']];nu=[F(v,D).limit_denominator(1000000)for v in c['equality_multipliers']];scale=lcm(*(v.denominator for v in z+nu));c['denominator']=scale;c['inequality_multipliers']=[[row,int(v*scale)]for (row,_),v in zip(c['inequality_multipliers'],z)];c['equality_multipliers']=[int(v*scale)for v in nu]
print(check(c,check_protected=False))
records=[]
for run in d['runs'][1:]:
 rec={'m':d['m'],'P':d['P'],'zero_pair':run['zero_pair'],'ineq':[str(F(float(v)).limit_denominator(1000000))for v in run['ineq']],'eq':[str(F(float(v)).limit_denominator(1000000))for v in run['eq']]}
 print(run['zero_pair'],upper(rec));records.append(rec)
(p/'ADAPTIVE_BOUNDARY_COUNTEREXAMPLE.json').write_text(json.dumps({'unrestricted':c,'restrictions':records})+'\n')
