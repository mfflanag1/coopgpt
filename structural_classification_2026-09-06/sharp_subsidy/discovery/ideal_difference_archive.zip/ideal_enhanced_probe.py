from pathlib import Path
from itertools import product
from fractions import Fraction as Q
from math import lcm
import json
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from sector_min_core import core_rows
from cyclic_frontier_search import cyclic


def solve(m,P,name,enhanced=True):
 edges,core,special=core_rows(m,P);idx={e:k for k,e in enumerate(edges)};q=len(edges);n=q+6*m+3;X=q;H=q+3*m+3
 rows=[]
 for es,c in core:
  row={e:1 for e in es};row.update({X+j:v for j,v in c.items()});rows.append(row)
 for i in range(3*m):
  j=i%m;row={H+i:1}
  for s in range(3):row[idx[(s,j,j)]]=-1
  rows.append(row);rows.append({X+i:1,H+i:-1})
 U=sorted(set(range(3*m))-{s*m+j for t in P for s,j in enumerate(t)})
 pw={}
 for a,b,c in P:
  for e in ((0,a,b),(1,a,c),(2,b,c)):pw[idx[e]]=pw.get(idx[e],0)+1
 for i in U:rows.append({**pw,H+i:1})
 for t in special:
  if len(set(t))!=2:continue
  label=next(j for j in t if t.count(j)==2);s=next(s for s,j in enumerate(t)if j!=label)
  # Full local completion minus tight repeated-label diagonal.
  row={H+s*m+label:1,H+s*m+t[s]:-1}
  for e in ((0,t[0],t[1]),(1,t[0],t[2]),(2,t[1],t[2])):
   if e in idx:row[idx[e]]=row.get(idx[e],0)+1
  for p in range(3):row[idx[(p,label,label)]]=row.get(idx[(p,label,label)],0)-1
  rows.append(row)
 if enhanced:
  def add(row,j,v):row[j]=row.get(j,0)+v
  for sector in range(3):
   incident=[p for p,(s,t) in enumerate([(0,1),(0,2),(1,2)])if sector in (s,t)]
   for a in range(m):
    for b in range(m):
     if a==b:continue
     row={H+sector*m+a:1,H+sector*m+b:-1}
     for p in incident:add(row,idx[(p,a,a)],-1)
     rows.append(row)
  from itertools import permutations
  for team in P:
   for s,t,u in permutations(range(3)):
    a,b,c=team[s],team[t],team[u];row={}
    add(row,H+u*m+b,1);add(row,H+u*m+c,-1)
    for edge in ((0,team[0],team[1]),(1,team[0],team[2]),(2,team[1],team[2])):add(row,idx[edge],1)
    for p in range(3):add(row,idx[(p,b,b)],-1)
    for p,(v,z) in enumerate([(0,1),(0,2),(1,2)]):
     if s in (v,z):add(row,idx[(p,a,a)],-1)
    rows.append(row)
 ri=[];ci=[];vv=[]
 for k,row in enumerate(rows):
  for j,v in row.items():ri.append(k);ci.append(j);vv.append(v)
 A=coo_matrix((vv,(ri,ci)),shape=(len(rows),n)).tocsr();b=np.zeros(len(rows));start=len(core)+6*m
 for k in range(len(U)):b[start+k]=1
 E=np.zeros((2,n))
 for s in range(3):
  for j in range(m):E[0,idx[(s,j,j)]]=1
 E[1,X:X+3*m]=1
 c=np.zeros(n)
 for j,v in pw.items():c[j]=v
 for i in U:c[H+i]=1/3
 res=linprog(-c,A_ub=A,b_ub=b,A_eq=E,b_eq=[1,1],bounds=(0,1))
 if not res.success:raise RuntimeError(res.message)
 vals=[Q(float(v)).limit_denominator(100000)for v in res.x];D=lcm(*(v.denominator for v in vals));ints=[int(v*D)for v in vals]
 exact=all(sum(v*ints[j]for j,v in row.items())<=int(rhs)*D for row,rhs in zip(rows,b))and sum(ints[j]for j in np.flatnonzero(E[0]))==D and sum(ints[X:X+3*m])==D
 out={'name':name,'m':m,'P':P,'primal_denominator':D,'primal_integers':ints,'exact_primal_feasible':exact,'objective':-res.fun-1,'rows':len(rows)}
 Path(__file__).with_name(name+'.json').write_text(json.dumps(out)+'\n');print(name,-res.fun-1,'exact',exact,flush=True)
 return out
if __name__=='__main__':
 for r in (2,4,6,8):
  m,P=cyclic(r,0,1);solve(m,P,f'IDEAL_ENHANCED_UNICYCLE_{r}')
