from pathlib import Path
from fractions import Fraction as Q
import json,sys
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from sector_min_core import core_rows
root=Path(__file__).parent;d=json.loads((root/'IDEAL_ENHANCED_UNICYCLE_4.json').read_text());m=d['m'];edges,_,_=core_rows(m,d['P']);idx={e:i for i,e in enumerate(edges)};weights=np.array(d['primal_integers'][:len(edges)],float);T=d['primal_denominator'];teams=[];values=[];ri=[];ci=[]
from itertools import product
for a,b,c in product(range(m),repeat=3):
 es=[idx[e]for e in((0,a,b),(1,a,c),(2,b,c))if e in idx];v=sum(weights[e]for e in es)
 if not v:continue
 row=len(teams);teams.append((a,m+b,2*m+c));values.append(v)
 for j in teams[-1]:ri.append(row);ci.append(j)
A=coo_matrix((np.ones(len(ri)),(ri,ci)),shape=(len(teams),3*m)).tocsr();H=[];xs=[];duals=[]
for i in range(3*m):
 obj=np.zeros(3*m);obj[i]=-1;r=linprog(obj,A_ub=-A,b_ub=-np.array(values),A_eq=np.ones((1,3*m)),b_eq=[T],bounds=(0,None));H.append(Q(float(-r.fun)).limit_denominator(1000));xs.append([str(Q(float(v)).limit_denominator(1000))for v in r.x]);duals.append({'nu':str(Q(float(-r.eqlin.marginals[0])).limit_denominator(1000)),'lambda':[[k,str(Q(float(-v)).limit_denominator(1000))]for k,v in enumerate(r.ineqlin.marginals)if v<-1e-8]})
r=linprog(np.ones(3*m),A_ub=-A,b_ub=-np.array(values),bounds=[(float(v/3),None)for v in H]);out={'m':m,'P':d['P'],'T':T,'weights':weights.astype(int).tolist(),'H':list(map(str,H)),'core_witnesses':xs,'ideal_upper_duals':duals,'protected_y':[str(Q(float(v)).limit_denominator(1000))for v in r.x],'subsidy':str(Q(float(r.fun-T)).limit_denominator(1000)),'teams':[list(t)for t in teams]}
(root/'IDEAL_ENHANCED_ACTUAL.json').write_text(json.dumps(out)+'\n');print('H',H,'subsidy',out['subsidy'])
