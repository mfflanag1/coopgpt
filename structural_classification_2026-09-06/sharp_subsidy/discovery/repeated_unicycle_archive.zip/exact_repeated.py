import json
from pathlib import Path
from fractions import Fraction as F
from math import lcm
from verify_cyclic_patterns import check
p=Path(__file__).with_name('REPEATED_UNICYCLE_AUDIT.json');d=json.loads(p.read_text())
for record in d['records']:
 c=record['certificate'];old=c['denominator']
 z=[F(v,old).limit_denominator(10000) for _,v in c['inequality_multipliers']];nu=[F(v,old).limit_denominator(10000) for v in c['equality_multipliers']];D=lcm(*(a.denominator for a in z+nu));c['denominator']=D
 c['inequality_multipliers']=[[row,int(v*D)] for (row,_),v in zip(c['inequality_multipliers'],z)];c['equality_multipliers']=[int(v*D)for v in nu]
 record['verification']=check(c,check_protected=False);print(record['verification'])
p.write_text(json.dumps(d)+'\n')
