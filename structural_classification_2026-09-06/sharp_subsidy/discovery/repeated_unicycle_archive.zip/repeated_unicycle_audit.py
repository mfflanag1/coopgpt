from itertools import product,combinations,permutations
from pathlib import Path
import json
from cyclic_frontier_weights import solve
from verify_cyclic_patterns import check

def canonical(P):
 return min(tuple(sorted(tuple(p[t[s]] for s in ss) for t in P)) for p in permutations(range(4)) for ss in permutations(range(3)))

def enumerate_patterns():
 reps=set();count=0
 for P in combinations(product(range(4),repeat=3),2):
  if any(P[0][s]==P[1][s] for s in range(3)):continue
  if set(P[0])|set(P[1])!=set(range(4)):continue
  if not set(P[0])&set(P[1]):continue
  if all(len(set(t))==3 for t in P):continue
  count+=1;reps.add(canonical(P))
 return count,sorted(reps)
if __name__=='__main__':
 count,reps=enumerate_patterns();print('COVERAGE',count,reps,flush=True)
 out=[]
 for k,P in enumerate(reps):
  d=solve(4,list(P),f'REPEATED_UNICYCLE_4_{k}')
  v=check(d,check_protected=False);print(v,flush=True);out.append({'certificate':d,'verification':v})
 Path(__file__).with_name('REPEATED_UNICYCLE_AUDIT.json').write_text(json.dumps({'labeled_patterns':count,'records':out})+'\n')
