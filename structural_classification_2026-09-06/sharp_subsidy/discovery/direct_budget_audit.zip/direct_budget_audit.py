import z3,json,time
Q=lambda n,d=1:z3.RealVal(n)/d
A,x,y,z=z3.Reals('alpha x y z');B=x+y+z
mx=lambda a,b:z3.If(a>=b,a,b)
mn=lambda a,b:z3.If(a<=b,a,b)
for kind in ['finite','localization']:
 solver=z3.SolverFor('QF_NRA');solver.set(timeout=20000)
 solver.add(A>0,A<=Q(1,3))
 for v in [x,y,z]:solver.add(v>=0,v<=1,v>=B-1,z3.Or(v==1,v<=1-A))
 solver.add(B<=Q(3,2))
 if kind=='finite':
  t=Q(4,5)+A/20;cycle=mx(0,1+A-B)
 else:
  cycle=z3.Real('cycle');solver.add(cycle>=0,B-1-A+cycle>=0)
  variance=sum((v-B/3)**2 for v in [x,y,z])
  eta=Q(2,3)*(Q(3,2)-B)*(B-Q(3,5))+variance+cycle
  t=Q(4,5)+z3.If(B<=1,Q(1,100),mn(1,eta)/100)
 delta=mx(0,t-2*A);beta=1-A
 demands=[]
 for v in [x,y,z]:
  n=1-B+v
  cap2=mn(v,beta);cap1=mn(v,beta-delta)
  demands.append(mx(0,v*delta-n*cap2-(1-n)*cap1))
 budget=(1-t)*(3-2*B)+(2-t)*(B-1-A+cycle)
 solver.add(sum(demands)>budget)
 start=time.monotonic();result=solver.check();out={'kind':kind,'result':str(result),'seconds':time.monotonic()-start}
 if result==z3.sat:out['model']=str(solver.model())
 if result==z3.unknown:out['reason']=solver.reason_unknown()
 print(json.dumps(out),flush=True)
