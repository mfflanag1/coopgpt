from pathlib import Path
import json
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from sparse_fixed_probe import layout
from cyclic_frontier_search import cyclic

def cycle_links(m,P):
 adj={i:set()for i in range(m+len(P))}
 for k,t in enumerate(P):
  for j in t:adj[j].add(m+k);adj[m+k].add(j)
 queue=[v for v in adj if len(adj[v])<2]
 while queue:
  v=queue.pop()
  for w in list(adj[v]):
   adj[w].remove(v)
   if len(adj[w])==1:queue.append(w)
  adj[v].clear()
 links=[]
 for k,t in enumerate(P):
  labs=adj[m+k]
  if len(labs)==2:
   ss=[s for s in range(3)if t[s]in labs]
   code={(0,1):0,(0,2):1,(1,2):2}[tuple(ss)]
   links.append((code,t[ss[0]],t[ss[1]]))
 return links

def probe(m,P):
 support,index,U,teams=layout(m,P);off=len(support);n=off+len(U)*3*m
 rr=[];cc=[];vv=[]
 for k in range(len(U)):
  for z,(t,es)in enumerate(teams):
   row=k*len(teams)+z
   for e in es:rr.append(row);cc.append(e);vv.append(1)
   for s,j in enumerate(t):rr.append(row);cc.append(off+k*3*m+s*m+j);vv.append(-1)
 A=coo_matrix((vv,(rr,cc)),shape=(len(U)*len(teams),n)).tocsr();er=[];ec=[]
 for j in range(m):
  for s in range(3):er.append(0);ec.append(index[s,j,j])
 for k in range(len(U)):
  for v in range(3*m):er.append(k+1);ec.append(off+k*3*m+v)
 E=coo_matrix((np.ones(len(er)),(er,ec)),shape=(len(U)+1,n)).tocsr();c=np.zeros(n)
 for a,b,d in P:
  for e in ((0,a,b),(1,a,d),(2,b,d)):c[index[e]]+=1
 for k,i in enumerate(U):c[off+k*3*m+i]=1/3
 out=[]
 for e in [None]+cycle_links(m,P):
  bounds=[(0,1)]*n
  if e is not None:bounds[index[e]]=(0,0)
  res=linprog(-c,A_ub=A,b_ub=np.zeros(A.shape[0]),A_eq=E,b_eq=np.ones(E.shape[0]),bounds=bounds,options={'time_limit':15})
  rec={'zero_pair':e,'success':bool(res.success),'message':res.message}
  if res.success:rec.update(value=-res.fun-1,primal=res.x.tolist(),ineq=(-res.ineqlin.marginals).tolist(),eq=(-res.eqlin.marginals).tolist())
  out.append(rec)
 return {'m':m,'P':P,'runs':out}
if __name__=='__main__':
 all=[]
 for r,seed in [(2,0),(3,0),(4,0),(6,0)]:
  m,P=cyclic(r,seed,1);d=probe(m,P);all.append(d);print(r,[(v['zero_pair'],v.get('value'))for v in d['runs']],flush=True)
  Path(__file__).with_name('CYCLE_BOUNDARY_DISCOVERY.json').write_text(json.dumps(all)+'\n')
  if all[-1]['runs'][0].get('value',0)>max((v.get('value',-100)for v in d['runs'][1:]),default=-100)+1e-7:break
