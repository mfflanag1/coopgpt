from pathlib import Path
import json,time
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from sector_min_core import core_rows
from cyclic_frontier_search import cyclic

def solve(m,P,name):
    edges,rows,special=core_rows(m,P);idx={e:i for i,e in enumerate(edges)};off=len(edges);U=sorted(set(range(3*m))-{s*m+j for t in P for s,j in enumerate(t)});block=3*m+3;n=off+len(U)*block
    ri=[];ci=[];vv=[]
    for k,i in enumerate(U):
        for r,(es,coeff)in enumerate(rows):
            row=k*len(rows)+r
            for e in es:ri.append(row);ci.append(e);vv.append(1)
            for j,v in coeff.items():ri.append(row);ci.append(off+k*block+j);vv.append(v)
    A=coo_matrix((vv,(ri,ci)),shape=(len(U)*len(rows),n)).tocsr();ri=[];ci=[]
    for s in range(3):
        for j in range(m):ri.append(0);ci.append(idx[(s,j,j)])
    for k,i in enumerate(U):
        for j in range(3*m):ri.append(k+1);ci.append(off+k*block+j)
    E=coo_matrix((np.ones(len(ri)),(ri,ci)),shape=(len(U)+1,n)).tocsr();c=np.zeros(n)
    for a,b,z in P:
        for e in ((0,a,b),(1,a,z),(2,b,z)):c[idx[e]]+=1
    for k,i in enumerate(U):c[off+k*block+i]=1/3
    start=time.monotonic();res=linprog(-c,A_ub=A,b_ub=np.zeros(A.shape[0]),A_eq=E,b_eq=np.ones(E.shape[0]),bounds=(0,1),options={'time_limit':35})
    out={'name':name,'m':m,'P':P,'rows_per_witness':len(rows),'constraints':A.shape[0],'variables':n,'success':bool(res.success),'message':res.message,'seconds':time.monotonic()-start}
    if res.success:
        out.update(objective=-res.fun-1,primal=res.x.tolist(),inequality_dual=(-res.ineqlin.marginals).tolist(),equality_dual=(-res.eqlin.marginals).tolist())
    Path(__file__).with_name(name+'.json').write_text(json.dumps(out)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k not in ['P','primal','inequality_dual','equality_dual']}),flush=True)
    return out

if __name__=='__main__':
    records=[]
    for r,seed in [(2,0),(4,1),(6,0),(12,0),(12,7),(16,0),(16,7),(24,0),(24,7)]:
        m,P=cyclic(r,seed,1);d=solve(m,P,f'SECTOR_MIN_UNICYCLE_{r}_{seed}');records.append({k:v for k,v in d.items()if k not in ['primal','inequality_dual','equality_dual']});Path(__file__).with_name('SECTOR_MIN_DISCOVERY.json').write_text(json.dumps(records)+'\n')
        if d.get('objective',0)>(r-1)/(3*r)+1e-7:
            print('CONJECTURED_FINITE_CORRECTION_VIOLATION',flush=True);break
