import z3,json,time
Q=lambda a,b=1:z3.RealVal(a)/b
A,B,x,y=z3.Reals('alpha B x y');z=B-x-y
for kind in ['finite','localization']:
 for branch in (0,1):
  for q in (1,2,3):
   s=z3.SolverFor('QF_NRA');s.set(timeout=8000)
   s.add(A>0,A<=Q(1,3),B>=0,B<=Q(3,2))
   for v in [x,y,z]:s.add(v>=0,v<=1-A,v>=B-1)
   if kind=='finite':
    t=Q(4,5)+A/20
    if branch==0:s.add(B<=1+A);n3=0
    else:s.add(B>=1+A);n3=B-1-A
   else:
    g=z3.Real('g');s.add(g>=0,B-1-A+g>=0);n3=B-1-A+g
    if branch==0:s.add(B<=1);t=Q(81,100)
    else:
     s.add(B>=1)
     V=sum((v-B/3)**2 for v in [x,y,z]);eta=Q(2,3)*(Q(3,2)-B)*(B-Q(3,5))+V+g
     t=Q(4,5)+z3.If(eta<=1,eta,Q(1))/100
   budget=(1-t)*(3-2*B)+(2-t)*n3
   fs=[v*(B-v)-B*(1-t)-A*(v+B)for v in [x,y,z]]
   s.add(sum(fs[:q])>budget)
   st=time.monotonic();r=s.check();d={'kind':kind,'branch':branch,'active_subset_size':q,'result':str(r),'seconds':time.monotonic()-st}
   if r==z3.sat:d['model']=str(s.model())
   if r==z3.unknown:d['reason']=s.reason_unknown()
   print(json.dumps(d),flush=True)
