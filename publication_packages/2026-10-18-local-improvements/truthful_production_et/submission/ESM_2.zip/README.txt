ONLINE RESOURCE 2 — Sharp subsidies for truthful production and network cooperation
Economic Theory submission candidate; NOT SUBMITTED
Author: Maxwell Flanagan; no affiliation
Correspondence: maxwell.flanagan@gmail.com
Location: New York City, United States
Original AI assistance: OpenAI Codex (historical model version not recorded).
Subsequent internal review: Anthropic Claude. The author personally reviewed
the manuscripts, proofs, code and results. No external submission is authorized.

current_sources/ contains the exact main/supplement sources of the final ET
candidate PDFs. historical_checks/verification/ preserves all 40 files from
the accepted October17 ESM_2.zip byte-for-byte. Those source snapshots, dated
logs and identity placeholders are historical verification inputs and are NOT
the sources of the current PDFs. Their checks remain applicable because the prior theorem/proof/equation text
is preserved. The current main adds a reader-facing exact two-profile payment
calculation only; no new theorem or source-priority clearance is asserted.
worked_example/ contains its standard-library rational-mask checker and result;
run python3 worked_example/check_worked_example.py from this archive's root.
The example is not a subsidy-necessity or lower-bound claim. research_record/ provides the original
October7 source referenced by Online Resource1, not another submission version.

Python3.10.14 standard-library checks previously passed five central jobs, five
portfolio jobs and the architecture transcription check. They were not rerun
for this illustrative update; only the new four-mask calculation was checked. See historical_checks/verification/README_CURRENT.txt
for commands from that directory in a disposable copy. Historical runners may
write adjacent result files. Exact finite checks are corroboration, not formal
verification or a proof of asymptotic claims. No external dataset is required.

This archive contains no retrieved third-party full-text articles. The source
and verification files are provided locally for review; no public deposit or
reuse license is inferred or selected by this preparation.
